package com.android.newsfeed;

import android.content.Context;
import android.util.Log;
import android.widget.ImageView;

import com.android.newsfeed.Api.MyApi;
import com.android.newsfeed.Api.MyRetrofit;
import com.android.newsfeed.Models.ArticlesModel;
import com.android.newsfeed.Models.NewsModel;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import androidx.databinding.BindingAdapter;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyListViewModel extends ViewModel {
    public String news_title="";
    public String news_desc="";
    public String news_urlToImage="";

    public MutableLiveData<ArrayList<MyListViewModel>> mutableLiveData = new MutableLiveData<>();
    private ArrayList<MyListViewModel> arrayList = new ArrayList<>();
    private List<ArticlesModel> articlesModels = new ArrayList<>();
    private NewsModel newsModels;
    public String getImageurl(){
        return news_urlToImage;
    }

    @BindingAdapter({"imageUrl"})
    public static void loadimage(ImageView imageView, String imageUrl){
        Picasso.with(imageView.getContext()).load(imageUrl).into(imageView);
    }

    public MyListViewModel(){

    }

    public MyListViewModel(ArticlesModel articlesModel){
        this.news_title=articlesModel.getTitle();
        this.news_desc=articlesModel.getDescription();
        this.news_urlToImage=articlesModel.getUrlToImage();
    }

    public MutableLiveData<ArrayList<MyListViewModel>> getMutableLiveData(Context context) {

        MyApi api= MyRetrofit.getInstance(context).getMyApi();
        Call<NewsModel> call=api.getNewsdata();
        call.enqueue(new Callback<NewsModel>() {
            @Override
            public void onResponse(Call<NewsModel> call, Response<NewsModel> response) {
                newsModels= new NewsModel();
                newsModels=response.body();
                articlesModels.clear();
                articlesModels = newsModels.getArticlesModelList();
                for (int i=0; i<articlesModels.size(); i++){
                    ArticlesModel myk=articlesModels.get(i);
                    MyListViewModel myListViewModel=new MyListViewModel(myk);
                    arrayList.add(myListViewModel);
                    mutableLiveData.setValue(arrayList);
                }

            }

            @Override
            public void onFailure(Call<NewsModel> call, Throwable t) {
                Log.e("error", t.getMessage().toString());
            }
        });

        return mutableLiveData;
    }
}