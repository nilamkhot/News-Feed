package com.android.newsfeed.Models;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class NewsModel {
    @SerializedName("status")
    public String status="";

    @SerializedName("totalResults")
    public int totalResults= 0;

    @SerializedName("articles")
    public List<ArticlesModel> articlesModelList = new ArrayList<>();

    public NewsModel()
    {

    }

    public NewsModel(String status, int totalResults, List<ArticlesModel> articlesModelList) {
        this.status = status;
        this.totalResults = totalResults;
        this.articlesModelList = articlesModelList;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(int totalResults) {
        this.totalResults = totalResults;
    }

    public List<ArticlesModel> getArticlesModelList() {
        return articlesModelList;
    }

    public void setArticlesModelList(List<ArticlesModel> articlesModelList) {
        this.articlesModelList = articlesModelList;
    }
}
