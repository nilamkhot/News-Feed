package com.android.newsfeed.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.android.newsfeed.MyListViewModel;
import com.android.newsfeed.R;
import com.android.newsfeed.databinding.MyListBinding;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

public class NewsAdapterFeed extends RecyclerView.Adapter<NewsAdapterFeed.ViewHolder> {
    private ArrayList<MyListViewModel> arrayList;
    private Context context;
    private LayoutInflater layoutInflater;

    public NewsAdapterFeed(ArrayList<MyListViewModel> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (layoutInflater==null){
            layoutInflater=LayoutInflater.from(parent.getContext());
        }
        MyListBinding myListBinding= DataBindingUtil.inflate(layoutInflater,R.layout.news_layout,parent,false);
        return new ViewHolder(myListBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MyListViewModel myListViewModel=arrayList.get(position);
        holder.bind(myListViewModel);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        private MyListBinding myListBinding;
        public ViewHolder(@NonNull MyListBinding myListBinding) {
            super(myListBinding.getRoot());
            this.myListBinding=myListBinding;
        }
        public void bind(MyListViewModel myli){
            this.myListBinding.setMylistmodel(myli);
            myListBinding.executePendingBindings();
        }
        public MyListBinding getMyListBinding(){
            return myListBinding;
        }
    }

}