package com.android.newsfeed;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Context;
import android.os.Bundle;

import com.android.newsfeed.Adapters.NewsAdapterFeed;
import com.android.newsfeed.Listener.EndlessRecyclerViewScrollListener;
import com.android.newsfeed.Models.NewsModel;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerview;
    SwipeRefreshLayout pullToRefresh;
    private List<NewsModel> newsList;
    NewsAdapterFeed adapter;
    LinearLayoutManager linearLayoutManager;
    private MyListViewModel myListViewModel;
    private EndlessRecyclerViewScrollListener scrollListener;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;

        LoadComponent();

    }

    private void LoadComponent() {

        recyclerview = findViewById(R.id.recyclerview);
        pullToRefresh = findViewById(R.id.pullToRefresh);
        linearLayoutManager = new LinearLayoutManager(getApplicationContext());

        pullToRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                LoadData();
                pullToRefresh.setRefreshing(false);

            }
        });

        LoadData();

        scrollListener = new EndlessRecyclerViewScrollListener(linearLayoutManager) {
            @Override
            public void onLoadMore(int page, int totalItemsCount, RecyclerView view) {
                // Triggered only when new data needs to be appended to the list
                // Add whatever code is needed to append new items to the bottom of the list
                loadNextDataFromApi();
            }
        };

        // Adds the scroll listener to RecyclerView
        recyclerview.addOnScrollListener(scrollListener);

    }

    private void LoadData() {

        myListViewModel= ViewModelProviders.of(MainActivity.this).get(MyListViewModel.class);
        myListViewModel.getMutableLiveData(context).observe(MainActivity.this, new Observer<ArrayList<MyListViewModel>>() {
            @Override
            public void onChanged(ArrayList<MyListViewModel> myListViewModels) {
                adapter=new NewsAdapterFeed(myListViewModels,MainActivity.this);
                recyclerview.setLayoutManager(linearLayoutManager);
                recyclerview.setAdapter(adapter);

            }
        });

    }

    public void loadNextDataFromApi() {
        // Send an API request to retrieve appropriate paginated data
        //  --> Send the request including an offset value (i.e `page`) as a query parameter.
        //  --> Deserialize and construct new model objects from the API response
        //  --> Append the new data objects to the existing set of items inside the array of items
        //  --> Notify the adapter of the new items made with `notifyItemRangeInserted()`

        myListViewModel.getMutableLiveData(context).observe(this, new Observer<ArrayList<MyListViewModel>>() {
            @Override
            public void onChanged(ArrayList<MyListViewModel> myListViewModels) {
                adapter.notifyDataSetChanged(); // or notifyItemRangeRemoved
                // Reset endless scroll listener when performing a new search
                scrollListener.resetState();
            }
        });
    }



}