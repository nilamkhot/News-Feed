package com.android.newsfeed.Api;

import com.android.newsfeed.Models.NewsModel;
import retrofit2.Call;
import retrofit2.http.GET;

public interface MyApi {

    @GET("v2/top-headlines?country=in&apiKey=372e1aae3b9b4de1b4d99c0450b7f570")
    Call<NewsModel> getNewsdata();

}
